let countdown;
let timeLeft;
let errors = 0;
let wpm = 0;
let isTyping = false;

const textToTypeElement = document.getElementById('text-to-type');
const userInput = document.getElementById('user-input');
const timeDisplay = document.getElementById('time');
const wpmDisplay = document.getElementById('wpm');
const errorsDisplay = document.getElementById('errors');
const restartBtn = document.getElementById('restart-btn');

// Sample paragraphs for typing
const paragraphs = [
    "The quick brown fox jumps over the lazy dog. This sentence contains every letter of the alphabet.",
    "A journey of a thousand miles begins with a single step. It is important to take that first step.",
    "In the middle of difficulty lies opportunity. Challenges can lead to great achievements.",
    "Success is not final, failure is not fatal: It is the courage to continue that counts.",
    "Life is what happens when you're busy making other plans. Embrace the unexpected."
];

// Function to select a random paragraph
function getRandomParagraph() {
    return paragraphs[Math.floor(Math.random() * paragraphs.length)];
}

// Start the typing test
function startTypingTest() {
    const paragraph = getRandomParagraph();
    textToTypeElement.innerText = paragraph;
    userInput.value = '';
    userInput.focus();
    
    // Calculate time based on word count (15 seconds per word)
    const wordCount = paragraph.split(' ').length;
    timeLeft = wordCount * 15; // 15 seconds per word
    timeDisplay.innerText = timeLeft;
    errors = 0;
    wpm = 0;
    isTyping = true;
    errorsDisplay.innerText = errors;
    wpmDisplay.innerText = wpm;

    clearInterval(countdown);
    countdown = setInterval(updateTime, 1000);
}

// Update the timer
function updateTime() {
    if (timeLeft > 0) {
        timeLeft--;
        timeDisplay.innerText = timeLeft;
    } else {
        endTest();
    }
}

// Check user input
userInput.addEventListener('input', function() {
    const typedText = userInput.value;
    const correctText = textToTypeElement.innerText.slice(0, typedText.length);

    if (typedText === correctText) {
        if (typedText.length === textToTypeElement.innerText.length) {
            endTest();
        }
    } else {
        errors = typedText.split('').filter((char, index) => char !== textToTypeElement.innerText[index]).length;
        errorsDisplay.innerText = errors;
    }

    wpm = Math.floor((typedText.length / 5) / ((60 - timeLeft) / 60));
    wpmDisplay.innerText = wpm;
});

// End the typing test
function endTest() {
    clearInterval(countdown);
    userInput.disabled = true;
    isTyping = false;
    alert("Test finished! Your WPM is ${wpm} and you made ${errors} errors.");
}

// Restart the typing test
restartBtn.addEventListener('click', function() {
    userInput.disabled = false;
    startTypingTest();
});

// Start the typing test on load
window.onload = startTypingTest;